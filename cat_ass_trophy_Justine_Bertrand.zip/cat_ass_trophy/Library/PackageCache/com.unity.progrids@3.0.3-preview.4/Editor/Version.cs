namespace UnityEditor.ProGrids
{
	static class Version
	{
		public static readonly SemVer current = new SemVer("3.0.3-preview.0", "2018-05-29");
	}
}
